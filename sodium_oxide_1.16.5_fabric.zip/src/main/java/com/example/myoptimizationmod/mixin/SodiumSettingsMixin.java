package com.example.myoptimizationmod.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(MinecraftClient.class)
public class SodiumSettingsMixin {
    // Оптимизационные настройки
}