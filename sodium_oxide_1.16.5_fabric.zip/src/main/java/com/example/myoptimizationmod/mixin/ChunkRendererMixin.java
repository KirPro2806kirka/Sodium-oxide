package com.example.myoptimizationmod.mixin;

import net.minecraft.client.render.chunk.ChunkRenderer;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(ChunkRenderer.class)
public class ChunkRendererMixin {
    // Оптимизация рендеринга чанков
}
